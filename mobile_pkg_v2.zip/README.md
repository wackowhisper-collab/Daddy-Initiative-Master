Daddy Initiative Mobile Package v2 — regenerated.
